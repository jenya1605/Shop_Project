package models;


import java.util.HashMap;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author 30471297
 */
public class Customer extends User{
    //Attributes
    private String addressLine1;
    private String addressLine2;
    private String town;
    private String postcode;
    private boolean isRegistered;
    private HashMap<Integer, Order> orderLines;
    
    //Constructor 0 input parameter
    public Customer ()
    {
        //call User()
       
       addressLine1 = "QueenStreet";
       addressLine2 = "Flat1";
       town = "Edinburgh";
       postcode = "EH99JJ";
       isRegistered = true;
       orderLines = new HashMap();
       
    }
    //Constructor 8 parameters, (except isRegistered)
    public Customer(String usernameIn, String passwordIn, String firstnameIn, String lastnameIn,
            String addressLine1In, String addressLine2In,String townIn,String postcodeIn)
    {
        //Call User(String usernameIn, String passwordIn, String firstnameIn, String lastnameIn)
        super(usernameIn,passwordIn,firstnameIn,lastnameIn);
        addressLine1 = addressLine1In;
        addressLine2 = addressLine2In;
        town = townIn;
        postcode = postcodeIn;
        isRegistered = false;
        orderLines = new HashMap();
        
    }
    //Getters
    public String getAddressLine1()
    {
        return addressLine1;
    }
    public String getAddressLine2()
    {
        return addressLine2;
    }
    public String getTown()
    {
        return town;
    }
       public String getPostcode()
    {
        return postcode;
    } 
           public Boolean getIsRegistered()
    {
        return isRegistered;
    }

    public HashMap <Integer, Order> getOrders() {
        return orderLines;
    }

        
    //Setters
    public void setAddressLine1(String addressLine1In)
    {
        addressLine1 = addressLine1In;
    }
    public void setAddressLine2(String addressLine2In)
    {
        addressLine2 = addressLine2In;
    }
    public void setTown(String townIn)
    {
        town = townIn;
    }
    public void setPostcode(String postcodeIn)
    {
        postcode = postcodeIn;
    }
    public void setIsRegistered(Boolean isRegisteredIn)
    {
        isRegistered = isRegisteredIn;
    }    

    public void setOrders(HashMap<Integer, Order> orderLinesIn) {
        orderLines = orderLinesIn;
    }
   
    
}
